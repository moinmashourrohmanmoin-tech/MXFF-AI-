create table public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid(),
  name text not null default 'নতুন প্রজেক্ট',
  favorite boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.project_messages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  role text not null check (role in ('user','assistant')),
  content text not null,
  created_at timestamptz not null default now()
);
create table public.project_versions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  html text not null,
  prompt text not null default '',
  created_at timestamptz not null default now()
);
create table public.project_files (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  name text not null,
  path text not null,
  url text not null,
  mime text not null default '',
  size bigint not null default 0,
  created_at timestamptz not null default now()
);
create table public.published_sites (
  slug text primary key check (slug ~ '^[a-z0-9][a-z0-9-]{1,40}$'),
  project_id uuid not null unique references public.projects(id) on delete cascade,
  user_id uuid not null default auth.uid(),
  html text not null,
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.projects, public.project_messages, public.project_versions, public.project_files, public.published_sites to authenticated;
grant all on public.projects, public.project_messages, public.project_versions, public.project_files, public.published_sites to service_role;
grant select on public.published_sites to anon;
alter table public.projects enable row level security;
alter table public.project_messages enable row level security;
alter table public.project_versions enable row level security;
alter table public.project_files enable row level security;
alter table public.published_sites enable row level security;
create policy "own projects" on public.projects for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own messages" on public.project_messages for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid() and exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy "own versions" on public.project_versions for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid() and exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy "own files" on public.project_files for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid() and exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy "public read sites" on public.published_sites for select to anon, authenticated using (true);
create policy "own sites write" on public.published_sites for insert to authenticated with check (user_id = auth.uid() and exists (select 1 from public.projects p where p.id = project_id and p.user_id = auth.uid()));
create policy "own sites update" on public.published_sites for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "own sites delete" on public.published_sites for delete to authenticated using (user_id = auth.uid());
create index on public.project_messages(project_id, created_at);
create index on public.project_versions(project_id, created_at);
create index on public.project_files(project_id, created_at);