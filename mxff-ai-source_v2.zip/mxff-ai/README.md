# MXFF AI

AI তে বলে ওযেবসাইট বানাও — MXFF AI একটাই HTML ফাইল বানিয়ে দেয়, চাট্‌র ভিতর থেকেই লাইভ প্রিভিউ দেখায়, ভার্সন রাখিয়ে রাখে, আর এক ক্লিকে প্রকাশ (publish) করিয়ে দেয়।

MXFF AI is a Lovable-style AI website builder: you describe what you want in chat, it streams a complete
self-contained website, shows live progress while writing, keeps version history, and publishes the
result to a public link — with real AI inside the built sites too.

## What's inside

| Area | Where |
| --- | --- |
| Home / dashboard (prompt box, project cards, search, star/rename/delete) | `src/routes/index.tsx` |
| Project page (chat + live preview, device toggle, version history, files, publish) | `src/routes/project.$id.tsx` |
| Sign in (email + Google) | `src/routes/auth.tsx`, `src/hooks/useAuth.tsx` |
| AI build endpoint (streams thinking + answer as NDJSON) | `src/routes/api/build.ts` |
| Real AI for published sites (`window.MXFF_AI.chat`) | `src/routes/api/public/site-ai.ts`, `src/lib/site-ai.ts` |
| Sees uploaded images / reads PDFs & text files | `src/lib/ai/attachments.server.ts` |
| AI gateway call (OpenAI Responses API) | `src/lib/ai/responses.server.ts` |
| Live step labels from the HTML being written | `src/lib/progress.ts`, `src/components/LiveProgress.tsx` |
| Reply parsing (summary + ```html block), uploads, slug, download | `src/lib/projects.ts` |
| Database schema + migrations | `drizzle/schema.ts`, `drizzle/migrations/` |
| Public site serving (`/s/<slug>`) | `src/routes/s.$slug.tsx` |

## Requirements

- Node.js 20+ (or Bun), and a Lovable Cloud (Supabase) project.
- Environment variables — copy `.env.example` to `.env` and fill in:
  - `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_PROJECT_ID`
  - `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_PROJECT_ID`
  - `LOVABLE_API_KEY` (AI gateway key, used server-side only)
  - `SUPABASE_SERVICE_ROLE_KEY` (only for the admin client in `src/integrations/supabase/client.server.ts`)

## Run it

```sh
npm install        # or: bun install
npm run dev        # or: bun run dev
```

Open http://localhost:8080

## Database

Tables (all in `public`, with row level security):

- `projects` — one row per build, plus `is_starred`
- `project_messages` — chat history
- `project_versions` — every generated HTML version
- `project_files` — uploaded files (stored in the private `project-files` bucket under `<userId>/<projectId>/`,
  with long-lived signed URLs kept in the row)
- `published_sites` — published HTML served publicly by slug

Migrations are in `drizzle/migrations/` (`0000` schema + grants + policies, `0001` storage policies).
Apply them with your usual SQL runner, or through Lovable Cloud.

## Tests

```sh
npx vitest run
```

## How a build flows

1. The prompt (plus history, current HTML, project files and attachments) is POSTed to `/api/build`.
2. The server verifies the signed-in user, then streams NDJSON events:
   `{"t":"r"}` = thinking, `{"t":"x"}` = answer text, `{"t":"e"}` = error.
3. The project page shows thinking + live step labels, and when the reply contains a
   ` ```html ` block it becomes the next preview + version.
4. Publishing copies the HTML into `published_sites`; `/s/<slug>` serves it and injects
   `window.MXFF_AI` so the built site can call real AI through `/api/public/site-ai`.

## Notes

- Built sites are single self-contained HTML files (multi-page via in-file hash routing).
- AI replies in whatever language the user writes (Bengali or English).
- Custom subdomains (e.g. `moin.mxffai.app`) are not supported; a purchased domain would give
  `mxffai.app/s/<slug>`.
