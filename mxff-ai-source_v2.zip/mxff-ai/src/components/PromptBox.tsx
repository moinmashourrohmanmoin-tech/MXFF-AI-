import { useRef, useState } from "react";
import { ArrowUp, FileText, Paperclip, Square, X } from "lucide-react";

export function PromptBox({
  onSubmit,
  busy,
  onStop,
  placeholder = "MXFF AI-কে জিজ্ঞেস করুন বা কিছু বানাতে বলুন…",
  autoFocus,
  big,
}: {
  onSubmit: (text: string, files: File[]) => void;
  busy?: boolean;
  onStop?: () => void;
  placeholder?: string;
  autoFocus?: boolean;
  big?: boolean;
}) {
  const [text, setText] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const send = () => {
    const t = text.trim();
    if ((!t && !files.length) || busy) return;
    onSubmit(t || "এই ফাইলগুলো দেখো।", files);
    setText("");
    setFiles([]);
  };
  const add = (list: FileList | null) => {
    if (!list) return;
    const ok = Array.from(list).filter((f) => {
      if (f.size > 20_000_000) {
        alert(`${f.name}: ফাইল ২০MB-এর বেশি / File is over 20MB`);
        return false;
      }
      return true;
    });
    setFiles((p) => [...p, ...ok].slice(0, 10));
  };
  return (
    <div
      className="ring-brand shadow-prompt w-full rounded-3xl bg-card/90 p-3 backdrop-blur"
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        add(e.dataTransfer.files);
      }}
    >
      {files.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-2 px-1">
          {files.map((f, i) => (
            <span key={i} className="flex max-w-[200px] items-center gap-1.5 rounded-xl border bg-secondary px-2 py-1 text-xs">
              {f.type.startsWith("image/") ? (
                <img src={URL.createObjectURL(f)} alt="" className="size-6 rounded object-cover" />
              ) : (
                <FileText className="size-4 shrink-0" />
              )}
              <span className="truncate">{f.name}</span>
              <button aria-label="সরান" onClick={() => setFiles(files.filter((_, j) => j !== i))}>
                <X className="size-3.5" />
              </button>
            </span>
          ))}
        </div>
      )}
      <textarea
        autoFocus={autoFocus}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            send();
          }
        }}
        rows={big ? 4 : 2}
        placeholder={placeholder}
        className="max-h-60 w-full resize-none bg-transparent px-2 py-1 text-[15px] outline-none placeholder:text-muted-foreground"
      />
      <div className="flex items-center justify-between">
        <input ref={fileRef} type="file" multiple hidden onChange={(e) => { add(e.target.files); e.target.value = ""; }} />
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm text-muted-foreground hover:bg-accent hover:text-foreground"
        >
          <Paperclip className="size-4" /> ফাইল / File
        </button>
        {busy ? (
          <button
            type="button"
            aria-label="থামান"
            onClick={onStop}
            className="flex size-10 items-center justify-center rounded-full bg-primary text-primary-foreground"
          >
            <Square className="size-3.5 fill-current" />
          </button>
        ) : (
          <button
            type="button"
            aria-label="পাঠান"
            onClick={send}
            disabled={!text.trim() && !files.length}
            className="bg-brand flex size-10 items-center justify-center rounded-full text-primary-foreground transition hover:scale-105 disabled:opacity-40"
          >
            <ArrowUp className="size-5" />
          </button>
        )}
      </div>
    </div>
  );
}
