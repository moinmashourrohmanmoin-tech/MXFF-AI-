import { useState } from "react";
import { Brain, Check, ChevronDown, FileCode2, Loader2 } from "lucide-react";
import { LogoMark } from "@/components/Logo";
import { buildSteps } from "@/lib/progress";
import { Markdown } from "@/components/Markdown";

export function LiveProgress({ thinking, summary, html }: { thinking: string; summary: string; html: string | null }) {
  const [open, setOpen] = useState(true);
  const steps = html ? buildSteps(html) : [];
  const writing = html !== null;
  const lastThought = thinking.trim().split("\n").filter(Boolean).slice(-6).join("\n");

  return (
    <div className="flex gap-2 text-sm">
      <LogoMark className="mt-0.5 size-5 shrink-0 animate-pulse" />
      <div className="min-w-0 flex-1 space-y-2">
        <div className="rounded-xl border bg-card/60">
          <button onClick={() => setOpen(!open)} className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-muted-foreground">
            <Brain className="size-3.5" />
            <span className="mr-auto">{writing ? "চিন্তা শেষ / Thought" : "চিন্তা করছে… / Thinking…"}</span>
            {!writing && <Loader2 className="size-3.5 animate-spin" />}
            <ChevronDown className={`size-3.5 transition ${open ? "rotate-180" : ""}`} />
          </button>
          {open && (
            <p className="max-h-40 overflow-y-auto whitespace-pre-wrap px-3 pb-2 text-xs leading-relaxed text-muted-foreground">
              {lastThought || "অনুরোধ বুঝছে… / Understanding your request…"}
            </p>
          )}
        </div>

        {summary && <Markdown text={summary} />}

        {writing && (
          <div className="rounded-xl border bg-card/60 p-2">
            <div className="flex items-center gap-2 px-1 pb-1.5 text-xs text-muted-foreground">
              <FileCode2 className="size-3.5" />
              <span className="mr-auto">index.html লিখছে / Editing</span>
              <span>{html.length.toLocaleString("bn-BD")} অক্ষর</span>
            </div>
            <ul className="space-y-1">
              {(steps.length ? steps : ["শুরু করছে / Starting"]).map((s, i, a) => (
                <li key={s} className="flex items-center gap-2 rounded-lg px-1.5 py-1 text-xs">
                  {i === a.length - 1 ? (
                    <Loader2 className="size-3.5 shrink-0 animate-spin text-magenta" />
                  ) : (
                    <Check className="size-3.5 shrink-0 text-cyan" />
                  )}
                  <span className={i === a.length - 1 ? "text-foreground" : "text-muted-foreground"}>{s}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}
