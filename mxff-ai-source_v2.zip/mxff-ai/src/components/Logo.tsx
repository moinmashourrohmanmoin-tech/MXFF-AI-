import { Link } from "@tanstack/react-router";
import logo from "@/assets/mxff-logo.png";

export function LogoMark({ className = "size-7" }: { className?: string }) {
  return <img src={logo} alt="MXFF AI" width={816} height={816} className={`${className} object-contain`} />;
}

export function Logo({ small }: { small?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2 font-bold tracking-tight">
      <LogoMark className={small ? "size-7" : "size-8"} />
      <span className={small ? "text-base" : "text-lg"}>
        MXFF <span className="text-brand">AI</span>
      </span>
    </Link>
  );
}
