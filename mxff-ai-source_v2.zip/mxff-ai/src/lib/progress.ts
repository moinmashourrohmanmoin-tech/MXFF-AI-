/** Turn the HTML being written into Lovable-style step labels, in the order they appear. */
export function buildSteps(html: string): string[] {
  const steps: string[] = [];
  const add = (s: string) => {
    if (!steps.includes(s)) steps.push(s);
  };
  const rules: [RegExp, (m: RegExpExecArray) => string][] = [
    [/<head/gi, () => "প্রজেক্ট শুরু করছে / Setting up"],
    [/<style/gi, () => "রঙ ও ডিজাইন সাজাচ্ছে / Styling"],
    [/<nav/gi, () => "মেনু বানাচ্ছে / Navigation"],
    [/data-page="([^"]+)"/gi, (m) => `পেজ: ${m[1]} / Page`],
    [/<section[^>]*id="([^"]+)"/gi, (m) => `অংশ: ${m[1]} / Section`],
    [/<form/gi, () => "ফর্ম যোগ করছে / Form"],
    [/<img/gi, () => "ছবি বসাচ্ছে / Images"],
    [/<footer/gi, () => "ফুটার বানাচ্ছে / Footer"],
    [/<script(?![^>]*src)/gi, () => "কাজের ফিচার যোগ করছে / Interactivity"],
  ];
  const found: { i: number; s: string }[] = [];
  for (const [re, label] of rules) {
    let m: RegExpExecArray | null;
    while ((m = re.exec(html))) found.push({ i: m.index, s: label(m) });
  }
  found.sort((a, b) => a.i - b.i).forEach((f) => add(f.s));
  return steps;
}
