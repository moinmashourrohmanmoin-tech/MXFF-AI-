/** Adds window.MXFF_AI to a generated site so its chat/AI features get real AI answers. */
export function injectSiteAI(html: string, origin: string, siteKey: string) {
  const script = `<script>window.MXFF_AI={async chat(messages,onToken){const r=await fetch(${JSON.stringify(origin + "/api/public/site-ai")},{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({site:${JSON.stringify(siteKey)},messages:messages})});if(!r.ok||!r.body){throw new Error((await r.text().catch(()=>""))||("AI error "+r.status))}const rd=r.body.getReader(),d=new TextDecoder();let t="";for(;;){const x=await rd.read();if(x.done)break;const c=d.decode(x.value,{stream:true});t+=c;if(onToken)onToken(c,t)}return t}};</script>`;
  if (/<head[^>]*>/i.test(html)) return html.replace(/<head[^>]*>/i, (m) => m + script);
  return script + html;
}
