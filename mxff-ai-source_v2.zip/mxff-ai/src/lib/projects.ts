import { supabase } from "@/integrations/supabase/client";

export type Msg = { role: "user" | "assistant"; content: string };
export type ProjectFile = { id: string; name: string; url: string; mime: string; size: number; created_at: string };

/** Split the AI reply into its short summary and the HTML document. */
export function parseReply(text: string): { summary: string; html: string | null } {
  const start = text.search(/```html/i);
  if (start === -1) return { summary: text.trim(), html: null };
  const summary = text.slice(0, start).trim();
  const rest = text.slice(start).replace(/^```html\s*/i, "");
  const end = rest.indexOf("```");
  const html = (end === -1 ? rest : rest.slice(0, end)).trim();
  return { summary, html: html || null };
}

export async function createProject(prompt: string) {
  const name = prompt.trim().slice(0, 40) || "নতুন প্রজেক্ট";
  const { data, error } = await supabase.from("projects").insert({ name }).select("id").single();
  if (error) throw error;
  return data.id;
}

/** Files picked on the home page, handed to the project page after navigation. */
export const pendingFiles = new Map<string, File[]>();

/** Upload files into the project's own folder and list them under the project's Files. */
export async function uploadFiles(projectId: string, files: File[]): Promise<ProjectFile[]> {
  const { data: u } = await supabase.auth.getUser();
  if (!u.user) throw new Error("আগে লগইন করুন।");
  const out: ProjectFile[] = [];
  for (const f of files) {
    const safe = f.name.replace(/[^\w.\-]+/g, "_");
    const path = `${u.user.id}/${projectId}/${Date.now()}-${safe}`;
    const up = await supabase.storage.from("project-files").upload(path, f, { contentType: f.type });
    if (up.error) throw up.error;
    const { data: s } = await supabase.storage.from("project-files").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
    const { data, error } = await supabase
      .from("project_files")
      .insert({ project_id: projectId, name: f.name, path, url: s?.signedUrl ?? "", mime: f.type, size: f.size })
      .select("id,name,url,mime,size,created_at")
      .single();
    if (error) throw error;
    out.push(data);
  }
  return out;
}

export function slugify(name: string) {
  const s = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 30);
  return s.length >= 2 ? s : `site-${Math.random().toString(36).slice(2, 8)}`;
}

export function downloadHtml(html: string, name: string) {
  const blob = new Blob([html], { type: "text/html" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `${name.replace(/[^\p{L}\p{N}]+/gu, "-") || "site"}.html`;
  a.click();
  URL.revokeObjectURL(a.href);
}
