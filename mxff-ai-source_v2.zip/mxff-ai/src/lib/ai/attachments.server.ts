export type Attachment = { name: string; url: string; mime: string };

type Part =
  | { type: "text"; text: string }
  | { type: "image"; image: URL }
  | { type: "file"; data: string; mediaType: string; filename: string };

const TEXTY = /^(text\/|application\/(json|xml|javascript|x-javascript|csv|x-yaml|yaml|sql|x-sh))/;
const TEXT_EXT = /\.(txt|md|html?|css|jsx?|tsx?|json|csv|xml|ya?ml|py|java|c|cpp|go|rs|php|rb|sql|sh|svg)$/i;

function toBase64(buf: ArrayBuffer) {
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

/** Build the user message so the model can actually see images, read PDFs and text files. */
export async function buildUserContent(text: string, attachments: Attachment[]): Promise<string | Part[]> {
  const list = attachments.filter((a) => a?.url?.startsWith("https://")).slice(0, 10);
  if (!list.length) return text;
  const parts: Part[] = [{ type: "text", text }];
  for (const a of list) {
    const mime = (a.mime || "").toLowerCase();
    try {
      if (mime.startsWith("image/") && mime !== "image/svg+xml") {
        parts.push({ type: "text", text: `Attached image "${a.name}" (URL usable in the site: ${a.url}):` });
        parts.push({ type: "image", image: new URL(a.url) });
      } else if (mime === "application/pdf") {
        const res = await fetch(a.url);
        if (!res.ok) throw new Error(String(res.status));
        parts.push({ type: "file", data: toBase64(await res.arrayBuffer()), mediaType: "application/pdf", filename: a.name });
      } else if (TEXTY.test(mime) || TEXT_EXT.test(a.name)) {
        const res = await fetch(a.url);
        if (!res.ok) throw new Error(String(res.status));
        const body = (await res.text()).slice(0, 60000);
        parts.push({ type: "text", text: `Attached file "${a.name}":\n\`\`\`\n${body}\n\`\`\`` });
      } else {
        parts.push({ type: "text", text: `Attached file "${a.name}" (${mime || "unknown type"}, cannot be read directly; URL: ${a.url}).` });
      }
    } catch {
      parts.push({ type: "text", text: `Attached file "${a.name}" could not be loaded.` });
    }
  }
  return parts;
}
