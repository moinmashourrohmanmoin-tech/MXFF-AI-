import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/hooks/useAuth";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "প্রবেশ করুন — mxff ai" },
      { name: "description", content: "mxff ai-তে লগইন বা নতুন অ্যাকাউন্ট খুলুন।" },
      { property: "og:title", content: "প্রবেশ করুন — mxff ai" },
      { property: "og:description", content: "mxff ai-তে লগইন বা নতুন অ্যাকাউন্ট খুলুন।" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const nav = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (user) nav({ to: "/" });
  }, [user, nav]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const { data, error } =
      mode === "in"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } });
    setBusy(false);
    if (error) return setMsg(error.message);
    if (mode === "up" && !data.session) setMsg("ইমেইলে পাঠানো লিংকে ক্লিক করে অ্যাকাউন্ট নিশ্চিত করুন।");
  };

  const google = async () => {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (r.error) setMsg(String(r.error.message ?? r.error));
  };

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4">
      <div className="bg-glow pointer-events-none absolute inset-0 opacity-70" />
      <div className="relative w-full max-w-sm rounded-3xl border bg-card p-7 shadow-prompt">
        <Logo />
        <h1 className="mt-6 text-2xl font-semibold">{mode === "in" ? "আবার স্বাগতম" : "অ্যাকাউন্ট খুলুন"}</h1>
        <button
          onClick={google}
          className="mt-6 w-full rounded-xl border bg-background py-2.5 text-sm font-medium hover:bg-accent"
        >
          Google দিয়ে চালিয়ে যান
        </button>
        <div className="my-4 text-center text-xs text-muted-foreground">অথবা</div>
        <form onSubmit={submit} className="space-y-3">
          <input
            type="email"
            required
            placeholder="ইমেইল"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-xl border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          <input
            type="password"
            required
            minLength={6}
            placeholder="পাসওয়ার্ড"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full rounded-xl border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
          <button
            disabled={busy}
            className="w-full rounded-xl bg-primary py-2.5 text-sm font-medium text-primary-foreground disabled:opacity-50"
          >
            {mode === "in" ? "লগইন" : "সাইন আপ"}
          </button>
        </form>
        {msg && <p className="mt-3 text-sm text-muted-foreground">{msg}</p>}
        <button
          onClick={() => setMode(mode === "in" ? "up" : "in")}
          className="mt-4 w-full text-sm text-muted-foreground hover:text-foreground"
        >
          {mode === "in" ? "অ্যাকাউন্ট নেই? সাইন আপ" : "অ্যাকাউন্ট আছে? লগইন"}
        </button>
      </div>
    </div>
  );
}
