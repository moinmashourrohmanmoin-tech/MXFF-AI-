import { createFileRoute } from "@tanstack/react-router";
import type { ModelMessage } from "ai";
import { createResponsesCall } from "@/lib/ai/responses.server";

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "POST, OPTIONS",
  "access-control-allow-headers": "content-type",
};

const SYSTEM = `You are the built-in AI assistant of a website made with MXFF AI. Be helpful, friendly and concise. Reply in the user's language (Bengali if they write Bengali). Use markdown when useful.`;

async function siteExists(site: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  if (/^[0-9a-f-]{36}$/i.test(site)) {
    const { data } = await supabaseAdmin.from("projects").select("id").eq("id", site).maybeSingle();
    return !!data;
  }
  const { data } = await supabaseAdmin.from("published_sites").select("slug").eq("slug", site).maybeSingle();
  return !!data;
}

export const Route = createFileRoute("/api/public/site-ai")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }) => {
        let body: { site?: string; messages?: { role: string; content: string }[] };
        try {
          body = await request.json();
        } catch {
          return new Response("Bad request", { status: 400, headers: CORS });
        }
        const site = String(body.site ?? "").slice(0, 64);
        if (!site || !(await siteExists(site))) return new Response("Unknown site", { status: 403, headers: CORS });
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) return new Response("AI not configured", { status: 500, headers: CORS });

        const messages: ModelMessage[] = (Array.isArray(body.messages) ? body.messages : [])
          .slice(-12)
          .filter((m) => m && (m.role === "user" || m.role === "assistant"))
          .map((m) => ({ role: m.role as "user" | "assistant", content: String(m.content ?? "").slice(0, 4000) }));
        if (messages.at(-1)?.role !== "user")
          return new Response("No message", { status: 400, headers: CORS });

        const call = createResponsesCall(
          request,
          { baseURL: "https://ai.gateway.lovable.dev", apiKey, model: "openai/gpt-6-astra" },
          messages,
          SYSTEM,
        );
        const res = call.result.toTextStreamResponse();
        const h = new Headers(res.headers);
        for (const [k, v] of Object.entries(CORS)) h.set(k, v);
        h.set("cache-control", "no-cache, no-transform");
        return new Response(res.body, { status: res.status, headers: h });
      },
    },
  },
});
