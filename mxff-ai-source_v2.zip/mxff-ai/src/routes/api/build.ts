import { createFileRoute } from "@tanstack/react-router";
import type { ModelMessage } from "ai";
import { buildUserContent, type Attachment } from "@/lib/ai/attachments.server";
import { createResponsesCall } from "@/lib/ai/responses.server";

const GATEWAY_URL = "https://ai.gateway.lovable.dev";
const MODEL = "openai/gpt-6-astra";

const INSTRUCTIONS = `You are MXFF AI, a friendly, expert AI assistant and web app builder (like Lovable).
LANGUAGE: Always reply in the language the user writes in (Bengali → Bengali, English → English). If the user asks you to switch language, do so.

You can SEE images and read files the user attaches: describe, analyse or use them (e.g. recreate a screenshot's design, use a photo, read a document). If the user only attached something and asked what it is, answer (A).

FIRST decide the user's intent:
A) QUESTION / CHAT (e.g. "what is React?", "how does this work?", greetings, advice, explanations): answer clearly and helpfully in markdown. Do NOT output any code block with html. Do NOT build or change the website.
B) BUILD / CHANGE request (also: a pasted plan, spec, feature list or design screenshot = build it fully) (make, create, build, add, change, fix, design, বানাও, তৈরি করো, যোগ করো, বদলাও…): build it.

For B:
- First write 1-3 short sentences describing what you built or changed.
- Then output the COMPLETE website as ONE self-contained HTML document inside one \`\`\`html code block. Nothing after the closing block.
- Multi-page sites: put each page in its own <section data-page="name"> and switch pages with a small hash router (location.hash) and a nav menu, so all pages work in one file.
- All CSS in <style>, JS in <script>. You may use CDNs (Tailwind CDN, Google Fonts, unpkg, lucide).
- Stunning, modern, responsive design; real interactivity; localStorage when useful. No TODOs or placeholders.
- Images: use the user's uploaded file URLs when relevant (e.g. a logo), otherwise high-quality photos from https://images.unsplash.com/photo-... or https://picsum.photos/seed/<word>/1200/800.
- REAL AI, NEVER DEMO: if the site needs AI (chatbot, AI chat app, writer, translator, assistant…), call the built-in helper \`await window.MXFF_AI.chat(messages, (chunk, fullText) => {...})\` where messages is [{role:"user"|"assistant", content:"..."}]. It returns the full answer text and streams chunks to the callback. It is always available; never use a fake/demo/mock reply, never ask for an API key, never say "demo mode". Render answers as markdown (e.g. marked from CDN) and show errors from it to the user.
- When a current version is given, apply the change to it and return the full updated file.`;

type Msg = { role: "user" | "assistant"; content: string };

async function verifyUser(request: Request) {
  const auth = request.headers.get("authorization") ?? "";
  const token = auth.replace(/^Bearer\s+/i, "");
  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!token || !url || !key) return false;
  const res = await fetch(`${url}/auth/v1/user`, {
    headers: { apikey: key, Authorization: `Bearer ${token}` },
  });
  return res.ok;
}

export const Route = createFileRoute("/api/build")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        if (!(await verifyUser(request))) {
          return Response.json({ error: "প্রবেশ করা নেই। আবার লগইন করুন।" }, { status: 401 });
        }
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) return Response.json({ error: "AI চালু করা নেই।" }, { status: 401 });

        let body: { history?: Msg[]; prompt?: string; currentHtml?: string | null; files?: { name: string; url: string; mime: string }[]; attachments?: Attachment[] };
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "ভুল অনুরোধ।" }, { status: 400 });
        }
        const prompt = (body.prompt ?? "").trim();
        if (!prompt) return Response.json({ error: "নির্দেশ খালি।" }, { status: 400 });

        const history = (body.history ?? []).slice(-10).map(
          (m): ModelMessage => ({ role: m.role, content: String(m.content).slice(0, 4000) }),
        );
        const current = body.currentHtml
          ? `\n\nCurrent version of the website:\n\`\`\`html\n${body.currentHtml.slice(0, 120000)}\n\`\`\``
          : "";
        const files = (body.files ?? []).slice(0, 30);
        const fileNote = files.length
          ? `\n\nProject files uploaded by the user (use these URLs directly):\n${files.map((f) => `- ${f.name} (${f.mime || "file"}): ${f.url}`).join("\n")}`
          : "";
        const content = await buildUserContent(prompt + fileNote + current, body.attachments ?? []);
        const messages: ModelMessage[] = [...history, { role: "user", content }];

        const call = createResponsesCall(
          request,
          { baseURL: GATEWAY_URL, apiKey, model: MODEL },
          messages,
          INSTRUCTIONS,
        );
        // NDJSON events: r = reasoning (thinking) delta, x = answer text delta, e = error
        const enc = new TextEncoder();
        const stream = new ReadableStream({
          async start(ctrl) {
            const send = (o: unknown) => ctrl.enqueue(enc.encode(JSON.stringify(o) + "\n"));
            try {
              for await (const p of call.result.fullStream as AsyncIterable<{ type: string; text?: string; delta?: string; error?: unknown }>) {
                const d = p.text ?? p.delta ?? "";
                if (p.type === "reasoning-delta" && d) send({ t: "r", d });
                else if (p.type === "text-delta" && d) send({ t: "x", d });
                else if (p.type === "error") send({ t: "e", d: String((p.error as Error)?.message ?? p.error) });
              }
            } catch (e) {
              send({ t: "e", d: (e as Error).message });
            }
            ctrl.close();
          },
        });
        return new Response(stream, {
          headers: { "content-type": "application/x-ndjson; charset=utf-8", "cache-control": "no-cache, no-transform" },
        });
      },
    },
  },
});
