import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Code2,
  Download,
  Eye,
  FolderOpen,
  Globe,
  FileText,
  History,
  Maximize2,
  MessageSquare,
  Monitor,
  Smartphone,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { PromptBox } from "@/components/PromptBox";
import { LogoMark } from "@/components/Logo";
import { LiveProgress } from "@/components/LiveProgress";
import { injectSiteAI } from "@/lib/site-ai";
import { Markdown } from "@/components/Markdown";
import { downloadHtml, parseReply, pendingFiles, slugify, uploadFiles, type Msg, type ProjectFile } from "@/lib/projects";

export const Route = createFileRoute("/project/$id")({
  head: () => ({
    meta: [
      { title: "প্রজেক্ট — mxff ai" },
      { name: "description", content: "mxff ai-তে আপনার ওয়েবসাইট বানান ও বদলান।" },
      { property: "og:title", content: "প্রজেক্ট — mxff ai" },
      { property: "og:description", content: "mxff ai-তে আপনার ওয়েবসাইট বানান ও বদলান।" },
    ],
  }),
  component: ProjectPage,
});

type Version = { id: string; html: string; prompt: string; created_at: string };

function ProjectPage() {
  const { id } = Route.useParams();
  const { user, session, loading } = useAuth();
  const nav = useNavigate();
  const [name, setName] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [versions, setVersions] = useState<Version[]>([]);
  const [html, setHtml] = useState<string | null>(null);
  const [streaming, setStreaming] = useState("");
  const [thinking, setThinking] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [tab, setTab] = useState<"preview" | "code">("preview");
  const [device, setDevice] = useState<"desktop" | "phone">("desktop");
  const [mobilePane, setMobilePane] = useState<"chat" | "preview">("chat");
  const [showHistory, setShowHistory] = useState(false);
  const [files, setFiles] = useState<ProjectFile[]>([]);
  const [showFiles, setShowFiles] = useState(false);
  const [siteSlug, setSiteSlug] = useState<string | null>(null);
  const [publishing, setPublishing] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    if (!loading && !user) nav({ to: "/auth" });
  }, [loading, user, nav]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: p } = await supabase.from("projects").select("name").eq("id", id).maybeSingle();
      if (!p) return setNotFound(true);
      setName(p.name);
      const [{ data: m }, { data: v }, { data: f }, { data: site }] = await Promise.all([
        supabase.from("project_messages").select("role,content").eq("project_id", id).order("created_at"),
        supabase.from("project_versions").select("id,html,prompt,created_at").eq("project_id", id).order("created_at"),
        supabase.from("project_files").select("id,name,url,mime,size,created_at").eq("project_id", id).order("created_at"),
        supabase.from("published_sites").select("slug").eq("project_id", id).maybeSingle(),
      ]);
      setFiles(f ?? []);
      setSiteSlug(site?.slug ?? null);
      setMessages((m ?? []) as Msg[]);
      setVersions(v ?? []);
      const last = v?.[v.length - 1];
      if (last) setHtml(last.html);
      const pending = sessionStorage.getItem(`mxff_start_${id}`);
      if (pending && !started.current && !(m ?? []).length) {
        started.current = true;
        sessionStorage.removeItem(`mxff_start_${id}`);
        send(pending, [], null, pendingFiles.get(id) ?? [], f ?? []);
        pendingFiles.delete(id);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streaming]);

  async function send(text: string, base: Msg[] = messages, currentHtml = html, newFiles: File[] = [], known: ProjectFile[] = files) {
    setError(null);
    let allFiles = known;
    let fresh: ProjectFile[] = [];
    if (newFiles.length) {
      try {
        const up = await uploadFiles(id, newFiles);
        fresh = up;
        allFiles = [...known, ...up];
        setFiles(allFiles);
        text += `\n\n[ফাইল: ${up.map((u) => u.name).join(", ")}]`;
      } catch (e) {
        setError("ফাইল আপলোড হয়নি: " + (e as Error).message);
        return;
      }
    }
    const next = [...base, { role: "user" as const, content: text }];
    setMessages(next);
    await supabase.from("project_messages").insert({ project_id: id, role: "user", content: text });
    setBusy(true);
    setStreaming("");
    setThinking("");
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    let full = "";
    try {
      const token = (await supabase.auth.getSession()).data.session?.access_token ?? session?.access_token;
      const res = await fetch("/api/build", {
        method: "POST",
        signal: ctrl.signal,
        headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
        body: JSON.stringify({ history: base, prompt: text, currentHtml, files: allFiles.map((f) => ({ name: f.name, url: f.url, mime: f.mime })), attachments: fresh.map((f) => ({ name: f.name, url: f.url, mime: f.mime })) }),
      });
      if (!res.ok || !res.body) {
        const j = await res.json().catch(() => null);
        const status = res.status;
        throw new Error(
          j?.error ??
            (status === 402
              ? "AI ক্রেডিট শেষ হয়ে গেছে।"
              : status === 429
                ? "অনেক বেশি অনুরোধ, একটু পরে আবার চেষ্টা করুন।"
                : `সমস্যা হয়েছে (${status})`),
        );
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      let thought = "";
      let streamErr = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const ev = JSON.parse(line) as { t: string; d: string };
            if (ev.t === "r") thought += ev.d;
            else if (ev.t === "x") full += ev.d;
            else if (ev.t === "e") streamErr = ev.d;
          } catch {
            /* partial line */
          }
        }
        setThinking(thought);
        setStreaming(full);
      }
      if (streamErr && !full.trim()) throw new Error(streamErr);
      const { summary, html: newHtml } = parseReply(full);
      if (!full.trim()) throw new Error("AI কোনো উত্তর দেয়নি। ক্রেডিট বা সংযোগ পরীক্ষা করুন।");
      const reply = summary || "ওয়েবসাইট তৈরি হয়েছে। / Website ready.";
      setMessages([...next, { role: "assistant", content: reply }]);
      await supabase.from("project_messages").insert({ project_id: id, role: "assistant", content: reply });
      if (newHtml) {
        const { data: v } = await supabase
          .from("project_versions")
          .insert({ project_id: id, html: newHtml, prompt: text })
          .select("id,html,prompt,created_at")
          .single();
        if (v) setVersions((vs) => [...vs, v]);
        setHtml(newHtml);
        setMobilePane("preview");
      }
      await supabase.from("projects").update({ updated_at: new Date().toISOString() }).eq("id", id);
    } catch (e) {
      if ((e as Error).name === "AbortError") {
        setMessages([...next, { role: "assistant", content: "কাজ থামানো হয়েছে।" }]);
      } else {
        setError((e as Error).message);
      }
    } finally {
      setBusy(false);
      setStreaming("");
      abortRef.current = null;
    }
  }

  async function publish() {
    if (!html) return;
    setPublishing(true);
    try {
      let slug = siteSlug;
      if (!slug) {
        const want = window.prompt("সাইটের নাম (ইংরেজি অক্ষর) / Site name", slugify(name));
        if (!want) return;
        slug = slugify(want);
        const { error } = await supabase.from("published_sites").insert({ slug, project_id: id, html });
        if (error) throw new Error(error.code === "23505" ? "এই নামটি আগে থেকেই নেওয়া। অন্য নাম দিন। / Name taken." : error.message);
        setSiteSlug(slug);
      } else {
        const { error } = await supabase.from("published_sites").update({ html, updated_at: new Date().toISOString() }).eq("slug", slug);
        if (error) throw error;
      }
      const link = `${window.location.origin}/s/${slug}`;
      await navigator.clipboard?.writeText(link).catch(() => {});
      window.open(link, "_blank");
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setPublishing(false);
    }
  }

  if (notFound)
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-3 p-6 text-center">
        <p className="text-lg font-semibold">প্রজেক্ট পাওয়া যায়নি</p>
        <p className="text-sm text-muted-foreground">এটি নেই অথবা এটি আপনার নয়।</p>
        <Link to="/" className="rounded-full bg-primary px-4 py-2 text-sm text-primary-foreground">
          ফিরে যান
        </Link>
      </div>
    );

  const live = streaming ? parseReply(streaming) : null;

  return (
    <div className="flex h-dvh flex-col bg-surface">
      <header className="flex items-center gap-2 border-b bg-background px-3 py-2">
        <Link to="/" aria-label="ফিরে যান" className="rounded-lg p-2 hover:bg-accent">
          <ArrowLeft className="size-4" />
        </Link>
        <LogoMark className="size-6" />
        <p className="mr-auto truncate text-sm font-medium">{name}</p>
        {siteSlug && (
          <a href={`/s/${siteSlug}`} target="_blank" rel="noreferrer" className="hidden max-w-[220px] truncate text-xs text-muted-foreground underline sm:block">
            {typeof window !== "undefined" ? window.location.host : ""}/s/{siteSlug}
          </a>
        )}
        <button
          disabled={!html || publishing}
          onClick={publish}
          className="bg-brand flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm font-semibold text-primary-foreground disabled:opacity-40"
        >
          <Globe className="size-4" /> {publishing ? "…" : siteSlug ? "Update" : "Publish"}
        </button>
        <div className="flex rounded-lg border bg-surface p-0.5 md:hidden">
          <Seg on={mobilePane === "chat"} onClick={() => setMobilePane("chat")} label="আলাপ">
            <MessageSquare className="size-4" />
          </Seg>
          <Seg on={mobilePane === "preview"} onClick={() => setMobilePane("preview")} label="প্রিভিউ">
            <Eye className="size-4" />
          </Seg>
        </div>
      </header>
      <div className="flex min-h-0 flex-1">
        <aside
          className={`${mobilePane === "chat" ? "flex" : "hidden"} w-full flex-col border-r bg-background md:flex md:w-[400px] md:shrink-0`}
        >
          <div className="flex-1 space-y-4 overflow-y-auto p-4">
            {messages.length === 0 && !busy && (
              <p className="pt-10 text-center text-sm text-muted-foreground">কী বানাতে চান লিখুন।</p>
            )}
            {messages.map((m, i) =>
              m.role === "user" ? (
                <div key={i} className="ml-auto max-w-[85%] whitespace-pre-wrap rounded-2xl bg-bubble px-3.5 py-2 text-sm text-bubble-foreground">
                  {m.content.length > 600 ? m.content.slice(0, 600) + "…" : m.content}
                </div>
              ) : (
                <div key={i} className="flex gap-2 text-sm">
                  <LogoMark className="mt-0.5 size-5 shrink-0" />
                  <Markdown text={m.content} />
                </div>
              ),
            )}
            {busy && <LiveProgress thinking={thinking} summary={live?.summary ?? ""} html={live?.html ?? null} />}
            {error && (
              <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">
                {error}
              </div>
            )}
            <div ref={bottomRef} />
          </div>
          <div className="p-3">
            <PromptBox
              busy={busy}
              onStop={() => abortRef.current?.abort()}
              onSubmit={(t, fs) => send(t, messages, html, fs)}
              placeholder={html ? "কী বদলাতে চান বা জিজ্ঞেস করুন…" : "জিজ্ঞেস করুন বা কী বানাতে চান লিখুন…"}
            />
          </div>
        </aside>
        <main className={`${mobilePane === "preview" ? "flex" : "hidden"} min-w-0 flex-1 flex-col md:flex`}>
          <div className="flex flex-wrap items-center gap-2 border-b bg-background px-3 py-2">
            <div className="flex rounded-lg border bg-surface p-0.5">
              <Seg on={tab === "preview"} onClick={() => setTab("preview")} label="প্রিভিউ">
                <Eye className="size-4" />
              </Seg>
              <Seg on={tab === "code"} onClick={() => setTab("code")} label="কোড">
                <Code2 className="size-4" />
              </Seg>
            </div>
            <div className="flex rounded-lg border bg-surface p-0.5">
              <Seg on={device === "desktop"} onClick={() => setDevice("desktop")} label="কম্পিউটার">
                <Monitor className="size-4" />
              </Seg>
              <Seg on={device === "phone"} onClick={() => setDevice("phone")} label="ফোন">
                <Smartphone className="size-4" />
              </Seg>
            </div>
            <div className="ml-auto flex gap-1">
              <ToolBtn label="ফাইল / Files" onClick={() => { setShowFiles(!showFiles); setShowHistory(false); }}>
                <FolderOpen className="size-4" />
              </ToolBtn>
              <ToolBtn label="সংস্করণ" onClick={() => { setShowHistory(!showHistory); setShowFiles(false); }}>
                <History className="size-4" />
              </ToolBtn>
              <ToolBtn
                label="বড় করে দেখুন"
                onClick={() => {
                  if (!html) return;
                  const w = window.open();
                  if (w) {
                    w.document.write(injectSiteAI(html, window.location.origin, id));
                    w.document.close();
                  }
                }}
              >
                <Maximize2 className="size-4" />
              </ToolBtn>
              <ToolBtn label="ডাউনলোড" onClick={() => html && downloadHtml(html, name)}>
                <Download className="size-4" />
              </ToolBtn>
            </div>
          </div>
          <div className="relative min-h-0 flex-1">
            {showFiles && (
              <div className="absolute right-3 top-3 z-10 max-h-[70%] w-80 overflow-y-auto rounded-2xl border bg-popover p-2 shadow-prompt">
                <p className="px-2 py-1 text-xs font-medium text-muted-foreground">প্রজেক্টের ফাইল / Files ({files.length})</p>
                {files.length === 0 && <p className="p-2 text-sm text-muted-foreground">চ্যাটে ফাইল যোগ করলে এখানে থাকবে।</p>}
                {files.map((f) => (
                  <a key={f.id} href={f.url} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-lg p-2 text-sm hover:bg-accent">
                    {f.mime.startsWith("image/") ? <img src={f.url} alt="" className="size-9 rounded object-cover" /> : <FileText className="size-5 shrink-0" />}
                    <span className="min-w-0">
                      <span className="block truncate">{f.name}</span>
                      <span className="text-xs text-muted-foreground">{(f.size / 1024).toFixed(0)} KB</span>
                    </span>
                  </a>
                ))}
              </div>
            )}
            {showHistory && (
              <div className="absolute right-3 top-3 z-10 max-h-[70%] w-72 overflow-y-auto rounded-2xl border bg-popover p-2 shadow-prompt">
                <p className="px-2 py-1 text-xs font-medium text-muted-foreground">সংরক্ষিত সংস্করণ</p>
                {versions.length === 0 && <p className="p-2 text-sm text-muted-foreground">এখনো নেই</p>}
                {[...versions].reverse().map((v, i) => (
                  <button
                    key={v.id}
                    onClick={() => {
                      setHtml(v.html);
                      setShowHistory(false);
                    }}
                    className={`w-full rounded-lg p-2 text-left text-sm hover:bg-accent ${v.html === html ? "bg-accent" : ""}`}
                  >
                    <p className="truncate">
                      #{versions.length - i} {v.prompt}
                    </p>
                    <p className="text-xs text-muted-foreground">{new Date(v.created_at).toLocaleString("bn-BD")}</p>
                  </button>
                ))}
              </div>
            )}
            {!html ? (
              <div className="flex h-full items-center justify-center p-6 text-center text-sm text-muted-foreground">
                {busy ? "আপনার ওয়েবসাইট তৈরি হচ্ছে…" : "এখানে আপনার ওয়েবসাইট দেখা যাবে।"}
              </div>
            ) : tab === "code" ? (
              <pre className="h-full overflow-auto bg-background p-4 font-mono text-xs leading-relaxed">{html}</pre>
            ) : (
              <div className="flex h-full justify-center overflow-auto p-0 md:p-3">
                <iframe
                  title="প্রিভিউ"
                  srcDoc={injectSiteAI(html, window.location.origin, id)}
                  sandbox="allow-scripts allow-forms allow-modals allow-popups"
                  className={`h-full bg-card md:rounded-xl md:border ${device === "phone" ? "w-[390px] max-w-full" : "w-full"}`}
                />
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

function Seg(props: { on: boolean; onClick: () => void; label: string; children: React.ReactNode }) {
  return (
    <button
      aria-label={props.label}
      title={props.label}
      onClick={props.onClick}
      className={`flex items-center gap-1 rounded-md px-2 py-1 text-xs ${props.on ? "bg-background shadow-sm" : "text-muted-foreground"}`}
    >
      {props.children}
      <span className="hidden sm:inline">{props.label}</span>
    </button>
  );
}

function ToolBtn(props: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      aria-label={props.label}
      title={props.label}
      onClick={props.onClick}
      className="rounded-lg p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
    >
      {props.children}
    </button>
  );
}
