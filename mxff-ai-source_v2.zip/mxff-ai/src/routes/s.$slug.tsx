import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { injectSiteAI } from "@/lib/site-ai";

function notFoundPage() {
  return new Response(
    `<!doctype html><meta charset="utf-8"><title>Not found</title><body style="font-family:sans-serif;display:grid;place-items:center;height:100vh;background:#14111f;color:#eee"><div><h1>সাইট পাওয়া যায়নি / Site not found</h1><p>Made with MXFF AI</p></div>`,
    { status: 404, headers: { "content-type": "text/html; charset=utf-8" } },
  );
}

export const Route = createFileRoute("/s/$slug")({
  server: {
    handlers: {
      GET: async ({ params, request }) => {
        const url = process.env["SUPABASE_URL"];
        const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
        if (!url || !key) return notFoundPage();
        const db = createClient(url, key, {
          auth: { persistSession: false, autoRefreshToken: false },
          global: {
            fetch: (input, init) => {
              const h = new Headers(init?.headers);
              if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
              h.set("apikey", key);
              return fetch(input, { ...init, headers: h });
            },
          },
        });
        const { data } = await db.from("published_sites").select("html").eq("slug", params.slug).maybeSingle();
        if (!data) return notFoundPage();
        return new Response(injectSiteAI(data.html, new URL(request.url).origin, params.slug), {
          headers: { "content-type": "text/html; charset=utf-8", "cache-control": "public, max-age=30" },
        });
      },
    },
  },
});
