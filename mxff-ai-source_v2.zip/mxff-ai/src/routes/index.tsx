import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { Folder, Home as HomeIcon, LogOut, Menu, Pencil, Search, Star, Trash2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Logo, LogoMark } from "@/components/Logo";
import { PromptBox } from "@/components/PromptBox";
import { createProject, pendingFiles } from "@/lib/projects";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MXFF AI — জিজ্ঞেস করুন, বানান / Ask & build with AI" },
      { name: "description", content: "MXFF AI: প্রশ্নের উত্তর পান বা লিখে চালু ওয়েবসাইট বানান। Ask anything or build live websites by chatting." },
      { property: "og:title", content: "MXFF AI — Ask & build with AI" },
      { property: "og:description", content: "প্রশ্নের উত্তর পান বা লিখে চালু ওয়েবসাইট বানান। Ask anything or build websites by chatting." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

type View = "home" | "all" | "starred";
const IDEAS = ["একটি কফি শপের ওয়েবসাইট", "Portfolio for a photographer", "টু-ডু লিস্ট অ্যাপ", "React কী? সহজ করে বোঝাও"];

function Home() {
  const { user, loading } = useAuth();
  const nav = useNavigate();
  const [err, setErr] = useState<string | null>(null);
  const [view, setView] = useState<View>("home");
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    if (!user) return;
    const pending = sessionStorage.getItem("mxff_pending");
    if (pending) {
      sessionStorage.removeItem("mxff_pending");
      start(pending, []);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const start = async (text: string, files: File[]) => {
    if (!user) {
      sessionStorage.setItem("mxff_pending", text);
      return nav({ to: "/auth" });
    }
    try {
      const id = await createProject(text);
      sessionStorage.setItem(`mxff_start_${id}`, text);
      if (files.length) pendingFiles.set(id, files);
      nav({ to: "/project/$id", params: { id } });
    } catch (e) {
      setErr((e as Error).message);
    }
  };

  const name = user?.email?.split("@")[0];

  return (
    <div className="flex min-h-screen">
      {user && (
        <>
          {menuOpen && <div className="fixed inset-0 z-30 bg-background/70 md:hidden" onClick={() => setMenuOpen(false)} />}
          <aside
            className={`fixed inset-y-0 left-0 z-40 flex w-64 flex-col border-r bg-sidebar p-3 transition-transform md:sticky md:top-0 md:h-screen md:translate-x-0 ${menuOpen ? "translate-x-0" : "-translate-x-full"}`}
          >
            <div className="flex items-center justify-between px-2 py-2">
              <Logo small />
              <button className="md:hidden" aria-label="বন্ধ" onClick={() => setMenuOpen(false)}>
                <X className="size-5" />
              </button>
            </div>
            <nav className="mt-4 space-y-1">
              <NavItem on={view === "home"} onClick={() => { setView("home"); setMenuOpen(false); }} icon={<HomeIcon className="size-4" />}>Home</NavItem>
              <NavItem on={view === "all"} onClick={() => { setView("all"); setMenuOpen(false); }} icon={<Folder className="size-4" />}>সব প্রজেক্ট / All projects</NavItem>
              <NavItem on={view === "starred"} onClick={() => { setView("starred"); setMenuOpen(false); }} icon={<Star className="size-4" />}>পছন্দের / Starred</NavItem>
            </nav>
            <div className="mt-auto rounded-2xl border bg-card p-3">
              <div className="flex items-center gap-2">
                <span className="bg-brand flex size-8 items-center justify-center rounded-full text-sm font-bold text-primary-foreground">
                  {name?.slice(0, 1).toUpperCase()}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{name}</p>
                  <p className="text-xs text-muted-foreground">Free plan</p>
                </div>
              </div>
              <button
                onClick={() => supabase.auth.signOut()}
                className="mt-3 flex w-full items-center justify-center gap-1.5 rounded-xl border py-1.5 text-sm text-muted-foreground hover:bg-accent hover:text-foreground"
              >
                <LogOut className="size-4" /> লগআউট / Log out
              </button>
            </div>
          </aside>
        </>
      )}

      <div className="relative min-w-0 flex-1 overflow-hidden">
        <div className="bg-glow animate-float pointer-events-none absolute inset-x-0 -top-20 h-[760px]" />
        <header className="relative flex items-center justify-between px-5 py-4">
          {user ? (
            <button className="rounded-lg border p-2 md:invisible" aria-label="মেনু" onClick={() => setMenuOpen(true)}>
              <Menu className="size-5" />
            </button>
          ) : (
            <Logo />
          )}
          {!loading && !user && (
            <Link to="/auth" className="bg-brand rounded-full px-5 py-2 text-sm font-semibold text-primary-foreground">
              শুরু করুন / Get started
            </Link>
          )}
        </header>

        {view === "home" ? (
          <>
            <section className="relative mx-auto flex max-w-3xl flex-col items-center px-4 pt-10 pb-16 text-center sm:pt-20">
              <LogoMark className="size-16 drop-shadow-2xl" />
              <h1 className="mt-6 text-4xl font-bold tracking-tight sm:text-6xl">
                কী <span className="text-brand">বানাবেন</span> আজ{name ? `, ${name}` : ""}?
              </h1>
              <p className="mt-4 max-w-xl text-muted-foreground">
                যেকোনো প্রশ্ন করুন অথবা বলুন কী বানাতে চান — MXFF AI উত্তর দেবে বা চালু ওয়েবসাইট বানিয়ে দেবে।
              </p>
              <div className="mt-8 w-full text-left">
                <PromptBox onSubmit={start} autoFocus big />
              </div>
              <div className="mt-5 flex flex-wrap justify-center gap-2">
                {IDEAS.map((i) => (
                  <button key={i} onClick={() => start(i, [])} className="rounded-full border bg-card/60 px-3 py-1.5 text-xs text-muted-foreground backdrop-blur hover:bg-accent hover:text-foreground">
                    {i}
                  </button>
                ))}
              </div>
              {err && <p className="mt-3 text-sm text-destructive">{err}</p>}
            </section>
            {user && <ProjectList filter="all" limit={6} onSeeAll={() => setView("all")} />}
          </>
        ) : (
          user && <ProjectList filter={view} />
        )}
      </div>
    </div>
  );
}

function NavItem(props: { on: boolean; onClick: () => void; icon: ReactNode; children: ReactNode }) {
  return (
    <button
      onClick={props.onClick}
      className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-sm ${props.on ? "bg-sidebar-accent text-foreground" : "text-muted-foreground hover:bg-sidebar-accent hover:text-foreground"}`}
    >
      {props.icon}
      {props.children}
    </button>
  );
}

function ProjectList({ filter, limit, onSeeAll }: { filter: "all" | "starred"; limit?: number; onSeeAll?: () => void }) {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const { data: projects = [], isLoading } = useQuery({
    queryKey: ["projects"],
    queryFn: async () => {
      const { data, error } = await supabase.from("projects").select("*").order("updated_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ["projects"] });
  let shown = projects.filter((p) => (filter !== "starred" || p.favorite) && p.name.toLowerCase().includes(q.toLowerCase()));
  if (limit) shown = shown.slice(0, limit);

  return (
    <section className="relative mx-auto max-w-6xl px-4 pb-20 pt-4">
      <div className="rounded-3xl border bg-card/70 p-5 backdrop-blur">
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="mr-auto text-lg font-semibold">
            {filter === "starred" ? "পছন্দের / Starred" : "আমার প্রজেক্ট / My projects"}
          </h2>
          <div className="flex items-center gap-2 rounded-full border bg-background px-3 py-1.5">
            <Search className="size-4 text-muted-foreground" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="খুঁজুন / Search" className="w-32 bg-transparent text-sm outline-none sm:w-48" />
          </div>
          {onSeeAll && (
            <button onClick={onSeeAll} className="rounded-full border px-3 py-1.5 text-sm hover:bg-accent">
              সব দেখুন / See all
            </button>
          )}
        </div>
        {isLoading ? (
          <p className="py-10 text-center text-sm text-muted-foreground">লোড হচ্ছে…</p>
        ) : shown.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">এখনো কোনো প্রজেক্ট নেই। / No projects yet.</p>
        ) : (
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {shown.map((p, i) => (
              <div key={p.id} className="group overflow-hidden rounded-2xl border bg-background transition hover:-translate-y-0.5 hover:shadow-prompt">
                <Link to="/project/$id" params={{ id: p.id }} className="block">
                  <div className="bg-glow relative flex aspect-video items-center justify-center bg-surface" style={{ backgroundPosition: `${(i * 37) % 100}% 0` }}>
                    <span className="text-brand text-5xl font-bold">{p.name.slice(0, 1)}</span>
                  </div>
                </Link>
                <div className="flex items-center gap-1 p-3">
                  <Link to="/project/$id" params={{ id: p.id }} className="mr-auto min-w-0">
                    <p className="truncate text-sm font-medium">{p.name}</p>
                    <p className="text-xs text-muted-foreground">{new Date(p.updated_at).toLocaleDateString("bn-BD")}</p>
                  </Link>
                  <IconBtn label="Star" onClick={async () => { await supabase.from("projects").update({ favorite: !p.favorite }).eq("id", p.id); refresh(); }}>
                    <Star className={`size-4 ${p.favorite ? "fill-coral text-coral" : ""}`} />
                  </IconBtn>
                  <IconBtn label="নাম বদলান" onClick={async () => { const name = prompt("নতুন নাম", p.name)?.trim(); if (!name) return; await supabase.from("projects").update({ name }).eq("id", p.id); refresh(); }}>
                    <Pencil className="size-4" />
                  </IconBtn>
                  <IconBtn label="মুছুন" onClick={async () => { if (!confirm(`"${p.name}" মুছে ফেলবেন?`)) return; await supabase.from("projects").delete().eq("id", p.id); refresh(); }}>
                    <Trash2 className="size-4" />
                  </IconBtn>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

function IconBtn(props: { label: string; onClick: () => void; children: ReactNode }) {
  return (
    <button aria-label={props.label} title={props.label} onClick={props.onClick} className="rounded-lg p-2 text-muted-foreground hover:bg-accent hover:text-foreground">
      {props.children}
    </button>
  );
}
