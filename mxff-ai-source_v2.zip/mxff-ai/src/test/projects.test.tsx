import { describe, expect, it, vi } from "vitest";
vi.mock("@/integrations/supabase/client", () => ({ supabase: {} }));
import { parseReply, slugify } from "@/lib/projects";

describe("projects helpers", () => {
  it("question replies have no website", () => {
    expect(parseReply("React is a UI library.").html).toBeNull();
  });
  it("build replies split summary and html", () => {
    const r = parseReply("Built it.\n```html\n<h1>Hi</h1>\n```");
    expect(r).toEqual({ summary: "Built it.", html: "<h1>Hi</h1>" });
  });
  it("publish names become url-safe slugs", () => {
    expect(slugify("My Coffee Shop!")).toBe("my-coffee-shop");
  });
});
