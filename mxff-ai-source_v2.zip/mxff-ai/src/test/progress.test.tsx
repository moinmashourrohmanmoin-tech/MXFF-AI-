import { expect, it } from "vitest";
import { buildSteps } from "@/lib/progress";

it("lists build steps in the order they are written", () => {
  const steps = buildSteps('<head><style></style></head><nav></nav><section id="menu"></section><footer>');
  expect(steps).toEqual([
    "প্রজেক্ট শুরু করছে / Setting up",
    "রঙ ও ডিজাইন সাজাচ্ছে / Styling",
    "মেনু বানাচ্ছে / Navigation",
    "অংশ: menu / Section",
    "ফুটার বানাচ্ছে / Footer",
  ]);
});
