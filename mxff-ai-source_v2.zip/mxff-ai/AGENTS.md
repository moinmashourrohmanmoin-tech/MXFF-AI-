<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## MXFF AI rules
- Generated sites are single self-contained HTML files (multi-page via in-file hash routing) streamed from /api/build; keeps preview, versions and publishing simple.
- Published sites are served raw by the /s/$slug server route from published_sites (public read); custom subdomains are not supported by the platform.
- User uploads live in the private project-files bucket under <userId>/<projectId>/ with long-lived signed URLs stored in project_files, because public buckets are blocked in this workspace.
